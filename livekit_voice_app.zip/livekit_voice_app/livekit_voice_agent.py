#!/usr/bin/env python3
"""
livekit_voice_agent.py - LiveKit voice agent whose STT / LLM / TTS / turn-taking settings come from the UI, per session.

  python livekit_voice_agent.py dev

How it works: the web UI (app.py + static/index.html) asks the token server for a LiveKit token. The server puts your
settings into the token's agent-dispatch metadata. When you connect, LiveKit starts a job for this agent and passes that
metadata in `ctx.job.metadata`; this file validates it (voice_settings.sanitize) and builds the session from it.
Started without metadata (for example from the LiveKit Agent Console) it simply uses the defaults.

Providers per component:   livekit  = LiveKit Inference (models from your LiveKit Cloud project)
                           nvidia   = your NVIDIA API key (LLM: OpenAI-compatible API; STT/TTS: Riva via livekit-plugins-nvidia)
Turn-taking: Silero VAD + audio / semantic / vad / stt turn detection, preemptive generation, adaptive interruptions.
Tools: current time, weather (free Open-Meteo), safe calculator. Choose which are enabled in the UI.

Setup:  pip install -r requirements.txt   (+ optional: pip install livekit-plugins-nvidia   for NVIDIA STT/TTS)
        .env.local with LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET (and optionally NVIDIA_API_KEY)
"""
from __future__ import annotations

import ast
import asyncio
import json
import logging
import operator
import os
from datetime import datetime
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import aiohttp

try:
    from dotenv import load_dotenv
    load_dotenv(".env.local")
except ImportError:
    pass

from livekit import agents
from livekit.agents import (Agent, AgentServer, AgentSession, JobContext, JobProcess,
                            RunContext, TurnHandlingOptions, function_tool, inference)
from livekit.plugins import silero

from voice_settings import public_view, sanitize, uses_nvidia

logger = logging.getLogger("voice-agent")
AGENT_NAME = os.environ.get("AGENT_NAME", "my-agent")
HOLD_PHRASE = os.environ.get("HOLD_PHRASE", "1") == "1"


# ------------------------------------------------------------------------------------ tools
_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.Pow: operator.pow, ast.Mod: operator.mod, ast.FloorDiv: operator.floordiv,
        ast.USub: operator.neg, ast.UAdd: operator.pos}


def safe_eval(expr: str) -> float:
    """Arithmetic only (no names, calls or attributes), so it is safe to run on LLM-provided text."""
    def ev(n):
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)) and not isinstance(n.value, bool):
            return n.value
        if isinstance(n, ast.BinOp) and type(n.op) in _OPS:
            a, b = ev(n.left), ev(n.right)
            if isinstance(n.op, ast.Pow) and (abs(b) > 100 or abs(a) > 1e6):
                raise ValueError("number too large")
            return _OPS[type(n.op)](a, b)
        if isinstance(n, ast.UnaryOp) and type(n.op) in _OPS:
            return _OPS[type(n.op)](ev(n.operand))
        raise ValueError("unsupported expression")
    return ev(ast.parse(expr.strip(), mode="eval").body)


WEATHER_CODES = {0: "clear sky", 1: "mostly clear", 2: "partly cloudy", 3: "overcast", 45: "foggy", 48: "foggy",
                 51: "light drizzle", 53: "drizzle", 55: "heavy drizzle", 61: "light rain", 63: "rain", 65: "heavy rain",
                 71: "light snow", 73: "snow", 75: "heavy snow", 80: "rain showers", 81: "rain showers",
                 82: "violent rain showers", 95: "a thunderstorm", 96: "a thunderstorm with hail", 99: "a thunderstorm with hail"}


@function_tool()
async def get_current_time(context: RunContext, timezone: str = "UTC") -> str:
    """Get the current date and time in a place.

    Args:
        timezone: An IANA timezone name such as "Asia/Kolkata", "Europe/Paris" or "America/New_York".
    """
    try:
        now = datetime.now(ZoneInfo(timezone))
    except (ZoneInfoNotFoundError, ValueError):
        return f"I don't know the timezone '{timezone}'. Ask for an IANA name like Europe/London."
    return now.strftime(f"%A, %B %d, %Y, %I:%M %p in {timezone}")


@function_tool()
async def get_weather(context: RunContext, location: str) -> str:
    """Get the current weather for a city.

    Args:
        location: The city name as spoken, for example "Paris" or "Chennai".
    """
    if HOLD_PHRASE:
        try:                                   # tell the user we are working on it (does not block the tool)
            context.session.say("Let me check the weather.", add_to_chat_ctx=False)
        except Exception:
            logger.debug("could not speak hold phrase", exc_info=True)
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=8)) as http:
            async with http.get("https://geocoding-api.open-meteo.com/v1/search",
                                params={"name": location, "count": 1}) as r:
                geo = await r.json()
            if not geo.get("results"):
                return f"I couldn't find a place called {location}."
            place = geo["results"][0]
            async with http.get("https://api.open-meteo.com/v1/forecast", params={
                    "latitude": place["latitude"], "longitude": place["longitude"],
                    "current": "temperature_2m,wind_speed_10m,weather_code"}) as r:
                cur = (await r.json())["current"]
    except Exception as e:
        logger.warning("weather lookup failed: %r", e)
        return "The weather service did not answer. Please try again in a moment."
    desc = WEATHER_CODES.get(cur.get("weather_code"), "unclear conditions")
    return (f"In {place['name']}, {place.get('country', '')} it is {cur['temperature_2m']:.0f} degrees Celsius "
            f"with {desc} and wind at {cur['wind_speed_10m']:.0f} kilometres per hour.")


@function_tool()
async def calculate(context: RunContext, expression: str) -> str:
    """Do arithmetic exactly. Supports + - * / ** % and parentheses.

    Args:
        expression: A plain arithmetic expression, for example "(12.5 * 8) / 3".
    """
    try:
        value = safe_eval(expression)
    except ZeroDivisionError:
        return "That divides by zero."
    except Exception:
        return "I can only do plain arithmetic with numbers."
    return f"{expression} = {round(value, 6):g}"


TOOLS = {"get_current_time": get_current_time, "get_weather": get_weather, "calculate": calculate}


class Assistant(Agent):
    def __init__(self, settings: dict) -> None:
        super().__init__(instructions=settings["system_prompt"], tools=[TOOLS[t] for t in settings["tools"]])


# ------------------------------------------------------------------------------------ session from settings
def nvidia_key(s: dict) -> str:
    return s["nvidia_api_key"] or os.environ.get("NVIDIA_API_KEY", "")


def make_stt(s: dict):
    if s["stt_provider"] == "nvidia":
        try:
            from livekit.plugins import nvidia
        except ImportError as e:
            raise RuntimeError("NVIDIA STT needs:  pip install livekit-plugins-nvidia") from e
        return nvidia.STT(api_key=nvidia_key(s), language_code=s["stt_language"])
    return inference.STT(model=s["stt_model"], language=s["stt_language"])


def make_llm(s: dict):
    if s["llm_provider"] == "nvidia":
        try:
            from livekit.plugins import openai
        except ImportError as e:
            raise RuntimeError("NVIDIA LLM needs:  pip install 'livekit-agents[openai]~=1.8'") from e
        return openai.LLM(model=s["llm_model"], base_url="https://integrate.api.nvidia.com/v1", api_key=nvidia_key(s))
    return inference.LLM(model=s["llm_model"])


def make_tts(s: dict):
    if s["tts_provider"] == "nvidia":
        try:
            from livekit.plugins import nvidia
        except ImportError as e:
            raise RuntimeError("NVIDIA TTS needs:  pip install livekit-plugins-nvidia") from e
        return nvidia.TTS(api_key=nvidia_key(s), voice=s["tts_voice"], language_code=s["stt_language"])
    return inference.TTS(model=s["tts_model"], voice=s["tts_voice"])


def make_turn_detection(mode: str):
    if mode == "audio":
        return inference.TurnDetector()
    if mode == "semantic":                       # older text-based detector (deprecated but open weights); needs a job context
        from livekit.plugins.turn_detector.multilingual import MultilingualModel
        return MultilingualModel()
    return mode                                  # "vad" or "stt"


def build_session(vad, s: dict) -> AgentSession:
    if uses_nvidia(s) and not nvidia_key(s):
        raise RuntimeError("An NVIDIA provider is selected but no NVIDIA API key was given "
                           "(type one in the UI or set NVIDIA_API_KEY in .env.local)")
    return AgentSession(
        stt=make_stt(s), llm=make_llm(s), tts=make_tts(s), vad=vad,
        turn_handling=TurnHandlingOptions(
            turn_detection=make_turn_detection(s["turn_detector"]),
            endpointing={"mode": s["endpointing_mode"], "min_delay": s["min_delay"], "max_delay": s["max_delay"], "alpha": 0.9},
            interruption={"min_duration": s["interruption_min_duration"], "min_words": 0,
                          "false_interruption_timeout": 2.0, "resume_false_interruption": s["resume_false_interruption"]},
            preemptive_generation={"enabled": s["preemptive"], "preemptive_tts": s["preemptive_tts"],
                                   "max_speech_duration": 10.0, "max_retries": 3},
        ),
    )


server = AgentServer()


def prewarm(proc: JobProcess) -> None:
    proc.userdata["vad"] = silero.VAD.load()      # load once per worker process, not per call


server.setup_fnc = prewarm


async def publish(ctx: JobContext, **attrs: str) -> None:
    """Tell the UI what happened (shown in its 'Agent applied settings' box). Never allowed to break the session."""
    try:
        await ctx.room.local_participant.set_attributes({k: str(v) for k, v in attrs.items()})
    except Exception:
        logger.debug("could not publish attributes", exc_info=True)


@server.rtc_session(agent_name=AGENT_NAME)
async def entrypoint(ctx: JobContext) -> None:
    try:
        raw = json.loads(ctx.job.metadata) if ctx.job.metadata else {}
    except json.JSONDecodeError:
        logger.warning("dispatch metadata is not valid JSON; using defaults")
        raw = {}
    s, warnings = sanitize(raw)
    for w in warnings:
        logger.warning("settings: %s", w)
    await ctx.connect()

    try:
        session = build_session(ctx.proc.userdata["vad"], s)
    except Exception as e:
        logger.error("could not build the session: %s", e)
        await publish(ctx, **{"app.error": str(e)[:300]})
        ctx.shutdown(reason="invalid settings")
        return

    @session.on("user_input_transcribed")
    def _on_transcript(ev) -> None:
        if ev.is_final:
            logger.info("you: %s", ev.transcript)

    latest: dict[str, float] = {}               # newest per-turn latency numbers, also shown in the UI

    @session.on("conversation_item_added")
    def _on_item(ev) -> None:
        item = ev.item
        role, m = getattr(item, "role", None), getattr(item, "metrics", None)
        if role not in ("user", "assistant") or not m:
            return
        keys = ("transcription_delay", "end_of_turn_delay") if role == "user" else ("llm_node_ttft", "tts_node_ttfb")
        got = {f"{role}.{k}": round(float(m[k]), 3) for k in keys if isinstance(m.get(k), (int, float))}
        if got:
            latest.update(got)
            logger.info("latency %s", got)
            asyncio.ensure_future(publish(ctx, **{"app.latency": json.dumps(latest)}))

    logger.info("session settings: %s", json.dumps(public_view(s))[:600])
    await session.start(room=ctx.room, agent=Assistant(s))
    await publish(ctx, **{"app.applied": json.dumps({k: v for k, v in public_view(s).items() if k != "system_prompt"}),
                          "app.warnings": json.dumps(warnings)})
    await session.generate_reply(instructions=s["greeting"])


if __name__ == "__main__":
    agents.cli.run_app(server)
