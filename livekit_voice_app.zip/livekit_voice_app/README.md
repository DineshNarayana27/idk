# Voice agent tester (LiveKit Cloud + your own UI)

Three processes' worth of pieces, two terminals:

    browser UI (static/index.html)  --POST /api/token-->  app.py (token server, holds your LiveKit secret)
         |  WebRTC (LiveKit Cloud)                             |  puts your UI settings into the agent-dispatch metadata
         v                                                     v
    livekit_voice_agent.py  <-- LiveKit starts a job and passes the settings in ctx.job.metadata

## Run (GitHub Codespaces)
    python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    cp .env.local.example .env.local      # fill LIVEKIT_* (and NVIDIA_API_KEY if you want NVIDIA providers)
    python -m livekit.agents download-files

    # terminal 1
    python livekit_voice_agent.py dev
    # terminal 2
    python app.py                          # then open forwarded port 8000 (keep it PRIVATE) in your browser

Optional NVIDIA speech-to-text / TTS:  pip install livekit-plugins-nvidia

## Use it in your own application
Your UI only needs two things: call an endpoint like /api/token to get {url, token}, then `room.connect(url, token)` with the
LiveKit SDK (JS shown in static/index.html; React: @livekit/components-react, starter: livekit-examples/agent-starter-react).
Transcripts arrive on the `lk.transcription` text stream, typed input goes to `lk.chat`, and the agent state is the
`lk.agent.state` participant attribute. Settings travel as dispatch metadata (see app.py make_token and voice_settings.py).
Keep NVIDIA/LiveKit secrets on the server in production; do not let the browser send raw API keys.
