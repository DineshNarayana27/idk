"""
voice_settings.py - the ONE place that defines the per-session settings.

The web UI sends these to the token server; the token server validates them (sanitize) and puts them in the
LiveKit dispatch metadata; the agent reads them again (sanitize) when a session starts. Anything unknown or out
of range is dropped or clamped, so a browser can never inject arbitrary options into the agent.
"""
from __future__ import annotations

import re

PROVIDERS = ("livekit", "nvidia")
TURN_DETECTORS = ("audio", "semantic", "vad", "stt")
ENDPOINTING_MODES = ("dynamic", "fixed")
ALL_TOOLS = ("get_current_time", "get_weather", "calculate")

DEFAULT_PROMPT = (
    "You are a friendly, concise voice assistant.\n"
    "Your replies are spoken aloud: use short, natural sentences. Never use lists, markdown, emojis, asterisks or other symbols.\n"
    "Use the tools when they help: get_current_time for the time or date in a place, get_weather for weather, "
    "calculate for arithmetic. If a tool fails, say so briefly and offer an alternative.\n"
    "Keep answers to one to three sentences unless the user asks for more detail."
)

# What each provider uses when you pick it and leave the model/voice empty.
PROVIDER_DEFAULTS = {
    "llm": {"livekit": {"model": "google/gemma-4-31b-it"},
            "nvidia": {"model": "nvidia/nemotron-3.5-lightning-30b-a3b"}},
    "stt": {"livekit": {"model": "assemblyai/universal-3-6-pro", "language": "en"},
            "nvidia": {"model": "", "language": "en-US"}},          # NVIDIA plugin keeps its own streaming Parakeet model
    "tts": {"livekit": {"model": "fishaudio/s2.1-pro", "voice": "fa4c9eb3dccc4806b382b40d61c6b10a"},
            "nvidia": {"model": "", "voice": "Magpie-Multilingual.EN-US.Leo"}},
}

DEFAULTS = {
    "llm_provider": "livekit", "llm_model": PROVIDER_DEFAULTS["llm"]["livekit"]["model"],
    "stt_provider": "livekit", "stt_model": PROVIDER_DEFAULTS["stt"]["livekit"]["model"],
    "stt_language": PROVIDER_DEFAULTS["stt"]["livekit"]["language"],
    "tts_provider": "livekit", "tts_model": PROVIDER_DEFAULTS["tts"]["livekit"]["model"],
    "tts_voice": PROVIDER_DEFAULTS["tts"]["livekit"]["voice"],
    "turn_detector": "audio",
    "endpointing_mode": "dynamic", "min_delay": 0.3, "max_delay": 2.5,
    "interruption_min_duration": 0.5, "resume_false_interruption": True,
    "preemptive": True, "preemptive_tts": True,
    "system_prompt": DEFAULT_PROMPT,
    "greeting": "Greet the user briefly and offer your help.",
    "tools": list(ALL_TOOLS),
    "nvidia_api_key": "",
}

_ID_RE = re.compile(r"^[A-Za-z0-9_\-./:@]{1,120}$")           # model ids, voice ids, language codes
_KEY_RE = re.compile(r"^[A-Za-z0-9_\-.]{1,300}$")
_CTRL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")


def _num(v, lo, hi, default):
    try:
        x = float(v)
    except (TypeError, ValueError):
        return default
    return min(max(x, lo), hi)


def sanitize(raw) -> tuple[dict, list[str]]:
    """Return (clean settings with every key present, list of warnings about things that were dropped/clamped)."""
    out, warn = dict(DEFAULTS), []
    out["tools"] = list(DEFAULTS["tools"])
    if raw is None or raw == "":
        return out, warn
    if not isinstance(raw, dict):
        return out, ["settings must be a JSON object; using defaults"]

    def enum(key, choices):
        if key in raw:
            if raw[key] in choices:
                out[key] = raw[key]
            else:
                warn.append(f"{key}: '{raw[key]}' is not one of {list(choices)}; using '{out[key]}'")

    for k in ("llm_provider", "stt_provider", "tts_provider"):
        enum(k, PROVIDERS)
    enum("turn_detector", TURN_DETECTORS)
    enum("endpointing_mode", ENDPOINTING_MODES)

    def ident(key, fallback):
        v = raw.get(key)
        if v is None or (isinstance(v, str) and not v.strip()):
            out[key] = fallback
        elif isinstance(v, str) and _ID_RE.match(v.strip()):
            out[key] = v.strip()
        else:
            warn.append(f"{key}: invalid value; using '{fallback}'")
            out[key] = fallback

    pd = PROVIDER_DEFAULTS
    ident("llm_model", pd["llm"][out["llm_provider"]]["model"])
    ident("stt_model", pd["stt"][out["stt_provider"]]["model"])
    ident("stt_language", pd["stt"][out["stt_provider"]]["language"])
    ident("tts_model", pd["tts"][out["tts_provider"]]["model"])
    ident("tts_voice", pd["tts"][out["tts_provider"]]["voice"])
    if out["stt_provider"] == "nvidia":
        out["stt_model"] = ""        # the NVIDIA plugin's model and function id belong together, so the model is fixed
    if out["tts_provider"] == "nvidia":
        out["tts_model"] = ""

    out["min_delay"] = _num(raw.get("min_delay", out["min_delay"]), 0.0, 5.0, DEFAULTS["min_delay"])
    out["max_delay"] = _num(raw.get("max_delay", out["max_delay"]), 0.0, 10.0, DEFAULTS["max_delay"])
    if out["max_delay"] < out["min_delay"]:
        warn.append("max_delay was smaller than min_delay; raised to match")
        out["max_delay"] = out["min_delay"]
    out["interruption_min_duration"] = _num(raw.get("interruption_min_duration", out["interruption_min_duration"]),
                                            0.0, 3.0, DEFAULTS["interruption_min_duration"])
    for k in ("resume_false_interruption", "preemptive", "preemptive_tts"):
        if k in raw:
            out[k] = bool(raw[k])

    for k, limit in (("system_prompt", 4000), ("greeting", 500)):
        v = raw.get(k)
        if isinstance(v, str) and v.strip():
            v = _CTRL_RE.sub("", v).strip()
            if len(v) > limit:
                warn.append(f"{k} cut to {limit} characters")
                v = v[:limit]
            out[k] = v

    if "tools" in raw:
        if isinstance(raw["tools"], list):
            out["tools"] = [t for t in raw["tools"] if t in ALL_TOOLS]
        else:
            warn.append("tools must be a list; using all tools")

    key = raw.get("nvidia_api_key")
    if isinstance(key, str) and key.strip():
        if _KEY_RE.match(key.strip()):
            out["nvidia_api_key"] = key.strip()
        else:
            warn.append("nvidia_api_key has unexpected characters; ignored")
    return out, warn


def public_view(settings: dict) -> dict:
    """Same settings with the API key hidden (safe to log or show)."""
    v = dict(settings)
    if v.get("nvidia_api_key"):
        v["nvidia_api_key"] = "set (hidden)"
    return v


def uses_nvidia(settings: dict) -> bool:
    return "nvidia" in (settings["llm_provider"], settings["stt_provider"], settings["tts_provider"])
