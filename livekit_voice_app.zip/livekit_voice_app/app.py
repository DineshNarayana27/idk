#!/usr/bin/env python3
"""
app.py - tiny backend for the test UI.

  * serves static/index.html
  * POST /api/token : validates the settings from the UI, then returns a LiveKit access token that
    (a) lets the browser join a fresh room and (b) tells LiveKit to dispatch YOUR agent into it, carrying the
    settings as dispatch metadata (the agent reads them in ctx.job.metadata)
  * GET  /api/info  : defaults + whether the server already has the keys it needs

This is also the pattern for your real application: your own UI calls an endpoint like /api/token, gets {url, token},
and connects with the LiveKit SDK. The LiveKit API secret never leaves this server.

Run:  python app.py            (then open the forwarded port 8000 in your browser; keep the port PRIVATE)
"""
from __future__ import annotations

import json
import os
import secrets
from datetime import timedelta
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv(".env.local")
except ImportError:
    pass

from fastapi import Body, FastAPI, HTTPException
from fastapi.responses import FileResponse
from livekit import api

from voice_settings import DEFAULTS, PROVIDER_DEFAULTS, public_view, sanitize

HERE = Path(__file__).resolve().parent
AGENT_NAME = os.environ.get("AGENT_NAME", "my-agent")
TOKEN_TTL_MIN = 30

app = FastAPI(title="Voice agent test UI")


def livekit_env() -> tuple[str, str, str]:
    url, key, secret = (os.environ.get(k, "") for k in ("LIVEKIT_URL", "LIVEKIT_API_KEY", "LIVEKIT_API_SECRET"))
    return url, key, secret


def make_token(settings: dict, identity: str, room: str) -> str:
    url, key, secret = livekit_env()
    return (
        api.AccessToken(key, secret)
        .with_identity(identity)
        .with_name(identity)
        .with_grants(api.VideoGrants(room_join=True, room=room))
        .with_room_config(api.RoomConfiguration(
            agents=[api.RoomAgentDispatch(agent_name=AGENT_NAME, metadata=json.dumps(settings))]))
        .with_ttl(timedelta(minutes=TOKEN_TTL_MIN))
        .to_jwt()
    )


@app.get("/")
def index():
    return FileResponse(HERE / "static" / "index.html")


@app.get("/api/info")
def info():
    url, key, secret = livekit_env()
    d = dict(DEFAULTS)
    d["nvidia_api_key"] = ""
    return {"defaults": d, "provider_defaults": PROVIDER_DEFAULTS, "agent_name": AGENT_NAME, "livekit_configured": bool(url and key and secret),
            "nvidia_key_on_server": bool(os.environ.get("NVIDIA_API_KEY"))}


@app.post("/api/token")
def token(body: dict = Body(default={})):
    url, key, secret = livekit_env()
    if not (url and key and secret):
        raise HTTPException(500, "LIVEKIT_URL, LIVEKIT_API_KEY and LIVEKIT_API_SECRET must be set in .env.local")
    settings, warnings = sanitize(body.get("settings"))
    room = f"voice-test-{secrets.token_hex(4)}"
    identity = f"user-{secrets.token_hex(3)}"
    return {"url": url, "token": make_token(settings, identity, room), "room": room, "identity": identity,
            "agent_name": AGENT_NAME, "applied": public_view(settings), "warnings": warnings}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", "8000")))
